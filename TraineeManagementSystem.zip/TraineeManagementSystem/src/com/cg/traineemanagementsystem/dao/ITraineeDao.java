package com.cg.traineemanagementsystem.dao;

import com.cg.traineemanagementsystem.bean.Trainee;

public interface ITraineeDao {

	Trainee addTrainee(Trainee trainee);

}
