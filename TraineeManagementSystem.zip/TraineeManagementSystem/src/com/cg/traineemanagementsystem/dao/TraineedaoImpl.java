package com.cg.traineemanagementsystem.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineemanagementsystem.bean.Trainee;

@Repository
@Transactional
public class TraineedaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

}
