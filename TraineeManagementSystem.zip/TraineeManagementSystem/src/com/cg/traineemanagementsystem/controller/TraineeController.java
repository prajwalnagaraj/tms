package com.cg.traineemanagementsystem.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemanagementsystem.bean.Trainee;
import com.cg.traineemanagementsystem.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	private ITraineeService traineeService;

	@Autowired
	public ITraineeService getTraineeService() {
		return traineeService;
	}

	@Autowired
	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "login";
	}

	@RequestMapping("/operations")
	public String operations() {
		return "operation";
	}

	@RequestMapping("/addTraineeForms")
	public ModelAndView showAddTrainee() {
		Trainee trainee = new Trainee();

		return new ModelAndView("addTraineeForm", "trainee", trainee);
	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {

		ModelAndView view = null;

		if (!result.hasErrors()) {
			trainee = traineeService.addTrainee(trainee);
			view = new ModelAndView("addSuccess");
			view.addObject("traineeId", trainee.getTraineeId());
			System.out.println(trainee.getTraineeId());
			view.addObject("traineeName", trainee.getTraineeName());
			view.addObject("traineeDomain", trainee.getTraineeDomain());
			view.addObject("traineeLocation", trainee.getTraineeLocation());
		} else {
			view = new ModelAndView("addTraineeForm", "trainee", trainee);
		}
		return view;
	}

	@RequestMapping("/deleteTraineeForms")
	public ModelAndView deleteTrainee() {
		Trainee trainee = new Trainee();

		return new ModelAndView("deleteTraineeForm", "trainee", trainee);
	}

	@RequestMapping("showDeleteDetails")
	public ModelAndView showDeleteDetails() {
		Trainee trainee = new Trainee();

		return new ModelAndView("showDeleteDetails", "trainee", trainee);
	}

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {
		ModelAndView view = null;
		if (!result.hasErrors()) {
			// trainee = traineeService.deleteTrainee(trainee.getTraineeId());
			view = new ModelAndView("showDeleteDetails");
			view.addObject("traineeId", trainee.getTraineeId());
			view.addObject("traineeName", trainee.getTraineeName());
			view.addObject("traineeDomain", trainee.getTraineeDomain());
			view.addObject("traineeLocation", trainee.getTraineeLocation());
		} else {
			view = new ModelAndView("deleteTraineeForm", "trainee", trainee);
		}
		return view;
	}

}
