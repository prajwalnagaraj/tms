package com.cg.traineemanagementsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Trainee_Table")
@SecondaryTable(name = "login_details")
public class Trainee implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private int traineeId;
	@Column(table = "login_details")
	private String userName;
	@Column(table = "login_details")
	private String passWord;

	@NotEmpty(message = "Please Enter Trainee Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String traineeName;

	@NotEmpty(message = "Please Enter Valid Domain Name")
	private String traineeDomain;

	@NotEmpty(message = "Please Enter Valid Location Name")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Location must contain only alphabets")
	private String traineeLocation;

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	public Trainee(int traineeId, String traineeName, String traineeDomain,
			String traineeLocation) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	public Trainee() {
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public Trainee(String userName, String passWord) {
		super();
		this.userName = userName;
		this.passWord = passWord;
	}

}
