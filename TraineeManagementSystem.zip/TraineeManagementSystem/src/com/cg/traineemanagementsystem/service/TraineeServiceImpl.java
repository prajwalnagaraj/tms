package com.cg.traineemanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.traineemanagementsystem.bean.Trainee;
import com.cg.traineemanagementsystem.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
	ITraineeDao traineeDao;
	
	
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}
	
	
	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

}
