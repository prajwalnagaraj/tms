package com.cg.traineemanagementsystem.service;

import com.cg.traineemanagementsystem.bean.Trainee;

public interface ITraineeService {

	Trainee addTrainee(Trainee trainee);

}
