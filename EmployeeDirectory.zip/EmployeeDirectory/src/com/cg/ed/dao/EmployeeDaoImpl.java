package com.cg.ed.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ed.bean.Employee;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	private EntityManager manager = null;

	@Override
	public Employee addDetails(Employee employee) {
		manager.persist(employee);
		manager.flush();
		return employee;
	}

	@Override
	public List<Employee> getAllDetails() {
		TypedQuery<Employee> query = manager.createQuery(
				"SELECT e FROM Employee e", Employee.class);
		return query.getResultList();
	}

}
