package com.cg.ed.dao;

import java.util.List;

import com.cg.ed.bean.Employee;

public interface IEmployeeDao {

	Employee addDetails(Employee employee);

	List<Employee> getAllDetails();


}
