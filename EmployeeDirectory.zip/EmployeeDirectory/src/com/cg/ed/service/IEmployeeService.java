package com.cg.ed.service;

import java.util.List;

import com.cg.ed.bean.Employee;

public interface IEmployeeService {

	Employee addDetails(Employee employee);

	List<Employee> getAllDetails();

}
