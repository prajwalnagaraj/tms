package com.cg.ed.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ed.bean.Employee;
import com.cg.ed.dao.IEmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	IEmployeeDao dao;

	public IEmployeeDao getDao() {
		return dao;
	}

	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public Employee addDetails(Employee employee) {
		return dao.addDetails(employee);
	}

	@Override
	public List<Employee> getAllDetails() {
		return dao.getAllDetails();
	}

}
