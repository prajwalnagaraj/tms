package com.cg.ed.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ed.bean.Employee;
import com.cg.ed.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "homePage";
	}

	@RequestMapping("/register")
	public ModelAndView register() {
		Employee employee = new Employee();
		return new ModelAndView("registerForm", "employee", employee);
	}

	@RequestMapping("/registerEmployee")
	public ModelAndView registerEmployee(
			@ModelAttribute("employee") @Valid Employee employee,
			BindingResult result) {
		ModelAndView view = null;
		if (employee.getEmployeeName().isEmpty()) {
			throw new RuntimeException();
		}
		if (!result.hasErrors()) {
			employee = service.addDetails(employee);
			view = new ModelAndView("addSuccess");
			view.addObject("employeeId", employee.getEmployeeId());
			/*
			 * view.addObject("employeeName", employee.getEmployeeName());
			 * view.addObject("employeeSalary", employee.getEmployeeSalary());
			 * view.addObject("projectName", employee.getProjectName());
			 */
		} else {
			view = new ModelAndView("registerForm", "employee", employee);
		}
		return view;
	}

	@RequestMapping("view")
	public ModelAndView getDetails() {
		ModelAndView view = new ModelAndView();

		List<Employee> list = service.getAllDetails();
		if (list.isEmpty()) {
			String Message = "There are no Employees";
			view.setViewName("myError");
			view.addObject("msg", Message);
		} else {
			view.setViewName("viewAllList");
			view.addObject("list", list);
		}
		return view;

	}
}
