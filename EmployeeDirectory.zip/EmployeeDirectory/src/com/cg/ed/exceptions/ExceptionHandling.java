package com.cg.ed.exceptions;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandling {
	@ExceptionHandler(value = RuntimeException.class)
	public String exceptionHandling() {
		return "RuntimeException";
	}

}
