package com.cg.ed.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "Employee_Table")
public class Employee implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Range(min=100000, max=999999,message="ID should be equal to 6 digits")
	private Integer employeeId;

	@NotEmpty(message = "Please Enter Employee Name")
	@Pattern(regexp = "[A-Z]{1}[a-z]+$", message = "Name must start with capitals and contains only alphabets")
	@Size(min=4, max=30) 
	private String employeeName;

	@Range(min=5000, message="Salary should be greater than 5000.00")
	private Double employeeSalary;

	@NotEmpty(message = "Please Enter Project Name")
	@Pattern(regexp = "[A-Z]+$", message = "Project Name be in UPPERCASE only")
	private String projectName;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(Double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Employee(Integer employeeId, String employeeName,
			Double employeeSalary, String projectName) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.projectName = projectName;
	}

	public Employee() {
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeSalary=" + employeeSalary
				+ ", projectName=" + projectName + "]";
	}

}
