package com.cg.hbms.service;

import com.cg.hbms.bean.Hotel;
import com.cg.hbms.dao.HotelDaoImpl;
import com.cg.hbms.dao.IHotelDao;
import com.cg.hbms.exceptions.HMSExceptions;

public class HotelServiceImpl implements IHotelService {

	IHotelDao dao = new HotelDaoImpl();
	@Override
	public String getRole(String userName, String password) throws HMSExceptions {
		return dao.getRole(userName, password);
	}
	@Override
	public String addHotelDetails(Hotel hotel) throws HMSExceptions {
		return dao.addHotelDetails(hotel);
	}
	@Override
	public Hotel hotelDetails(int hotelId) throws HMSExceptions {
		return dao.hotelDetails(hotelId);
	}

}
