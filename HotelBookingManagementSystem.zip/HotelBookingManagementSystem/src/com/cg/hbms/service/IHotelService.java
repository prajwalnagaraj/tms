package com.cg.hbms.service;

import com.cg.hbms.bean.Hotel;
import com.cg.hbms.exceptions.HMSExceptions;

public interface IHotelService {

	String getRole(String userName, String password) throws HMSExceptions;

	String addHotelDetails(Hotel hotel)throws HMSExceptions;

	Hotel hotelDetails(int hotelId)throws HMSExceptions;

}
