package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hbms.bean.Hotel;
import com.cg.hbms.exceptions.HMSExceptionList;
import com.cg.hbms.exceptions.HMSExceptions;
import com.cg.hbms.utility.JdbcUtility;

public class HotelDaoImpl implements IHotelDao {
	Connection connection = null;
	PreparedStatement preparedStatement = null;

	@Override
	public String getRole(String userName, String password)
			throws HMSExceptions {
		String role = null;
		connection = JdbcUtility.getConnection();
		try {
			preparedStatement = connection
					.prepareStatement(IQueryConstants.Query1);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				role = resultSet.getString(1);
			} else {
				role = "Invalid Credintials or Username Does not exists";
			}
		} catch (SQLException e) {
			throw new HMSExceptions(HMSExceptionList.Error6);
		}
		return role;
	}

	@Override
	public String addHotelDetails(Hotel hotel) throws HMSExceptions {
		String hotelId = null;
		int insert = 0;
		connection = JdbcUtility.getConnection();
		try {
			preparedStatement = connection
					.prepareStatement(IQueryConstants.Query2);
			preparedStatement.setString(1, hotel.getHotelCity());
			System.out.println(hotel.getHotelCity());
			preparedStatement.setString(2, hotel.getHotelName());
			preparedStatement.setString(3, hotel.getAddress());
			preparedStatement.setString(4, hotel.getHotelDescription());
			preparedStatement.setDouble(5, hotel.getRate());
			preparedStatement.setString(6, hotel.getPhoneNumber1());
			preparedStatement.setString(7, hotel.getPhoneNumber2());
			preparedStatement.setString(8, hotel.getRating());
			preparedStatement.setString(9, hotel.geteMail());
			preparedStatement.setString(10, hotel.getFax());
			insert = preparedStatement.executeUpdate();
			if (insert >= 0) {
				PreparedStatement preparedStatement1 = connection
						.prepareStatement(IQueryConstants.Query3);
				preparedStatement1.setString(1, hotel.getHotelName());
				ResultSet resultSet = preparedStatement1.executeQuery();
				if (resultSet.next()) {
					hotelId = resultSet.getString(1);
				}
			}
		} catch (SQLException e) {
			throw new HMSExceptions(HMSExceptionList.Error6);
		}
		return hotelId;
	}

	@Override
	public Hotel hotelDetails(int hotelId) throws HMSExceptions {
		connection = JdbcUtility.getConnection();
		try {
			preparedStatement = connection
					.prepareStatement(IQueryConstants.Query4);
			preparedStatement.setInt(1, hotelId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				String hotelCity = resultSet.getString(2);
				System.out.println(hotelCity);
				String hotelName = resultSet.getString(3);
				String address = resultSet.getString(4);
				String hotelDescription = resultSet.getString(5);
				Double rate = resultSet.getDouble(6);
				String phoneNumber1 = resultSet.getString(7);
				String phoneNumber2 = resultSet.getString(8);
				String rating = resultSet.getString(9);
				String eMail = resultSet.getString(10);
				String fax = resultSet.getString(11);
				Hotel hotel = new Hotel(hotelCity, hotelName, address,
						hotelDescription, rate, phoneNumber1, phoneNumber2,
						rating, eMail, fax);
				System.out.println(hotel);
			}
		} catch (SQLException e) {
			throw new HMSExceptions(HMSExceptionList.Error6);
		}
		return null;
	}

}
