package com.cg.hbms.dao;

public interface IQueryConstants {

	String Query1 = "SELECT role FROM HMS_Login_Table WHERE username=? and password=?";
	String Query2 = "INSERT INTO hotel values(hotel_id_sequence.nextval,?,?,?,?,?,?,?,?,?,?)";
	String Query3 = "SELECT HOTEL_ID FROM hotel WHERE HOTEL_NAME=?";
	String Query4 = "SELECT * FROM hotel WHERE HOTEL_ID=?";

}
