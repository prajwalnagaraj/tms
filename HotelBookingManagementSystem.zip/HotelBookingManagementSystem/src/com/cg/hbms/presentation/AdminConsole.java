package com.cg.hbms.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.hbms.bean.Hotel;
import com.cg.hbms.exceptions.HMSExceptions;
import com.cg.hbms.service.HotelServiceImpl;
import com.cg.hbms.service.IHotelService;

public class AdminConsole {
	Scanner scanner = new Scanner(System.in);
	IHotelService service = new HotelServiceImpl();

	public void start(String userName) {
		int choice = 0;
		int choiceOption = 0;
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n"
				+ "~~~~~~~~~ Welcome " + userName + " ~~~~~~~~~\n"
				+ "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Select your option");
		System.out.println("Choose Following Options" + "\n"
				+ "[1]. Perform Hotel Management");
		System.out.println("[2]. Perform Room Management" + "\n"
				+ "[3]. View List of Hotels");
		System.out.println("[4]. View Bookings of specific hotel" + "\n"
				+ "[5]. View guest list of specific hotel");
		System.out.println("[6]. View bookings for specified date" + "\n"
				+ "[7]. Exit");
		try {
			choice = scanner.nextInt();
		} catch (InputMismatchException e) {
			System.err.println("Enter digits only(1-4)");
		}
		switch (choice) {
		case 1:
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n"
					+ "~~ Welcome Hotel Management Menu ~~" + "\n"
					+ "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("Select your option");
			System.out.println("Choose Following Options" + "\n"
					+ "[1]. Add Hotel Details");
			System.out.println("[2]. Delete Hotel Details" + "\n"
					+ "[3]. Modify Hotel Detailst");
			// System.out.println("[4]. Exit from Hotel Management Menu");
			try {
				choiceOption = scanner.nextInt();
				scanner.nextLine();
			} catch (InputMismatchException e) {
				System.err.println("Enter digits only(1-3)");
			}
			switch (choiceOption) {
			case 1:
				Hotel hotel = addHotelDetails();
				try {
					String id = service.addHotelDetails(hotel);
					System.out.println("Hotel " + hotel.getHotelName()
							+ " is registered successfully with id: " + id);
				} catch (HMSExceptions e) {
					System.err.println(e.getMessage());
				}
				break;

			case 2:
				System.out.println("Enter the Id of hotel to delete");
				int hotelId = scanner.nextInt(); 
				try {
					Hotel hotelDetails = service.hotelDetails(hotelId);
					System.out.println(hotelDetails.toString());
				} catch (HMSExceptions e) {
					System.err.println(e.getMessage());
				}
				
				break;
			default:
				break;
			}

			break;
		case 2:

		default:
			break;
		}
	}


	private Hotel addHotelDetails() {
		System.out.println("Enter the Hotel Details");
		System.out.println("Enter City");
		String hotelCity = scanner.nextLine();
		System.out.println("Enter Hotel Name");
		String hotelName = scanner.nextLine();
		System.out.println("Enter Address");
		String address = scanner.nextLine();
		System.out.println("Enter Description");
		String hotelDescription = scanner.nextLine();
		System.out.println("Enter Average Rate Per Night ");
		double rate = scanner.nextDouble();
		System.out.println("Enter Phone Number 1");
		String phoneNumber1 = scanner.next();
		System.out.println("Enter Phone Number 2");
		String phoneNumber2 = scanner.next();
		System.out.println("Enter Ratings");
		String rating = scanner.next();
		System.out.println("Enter Email");
		String eMail = scanner.next();
		System.out.println("Enter Fax");
		String fax = scanner.next();
		Hotel hotel = new Hotel(hotelCity, hotelName, address,
				hotelDescription, rate, phoneNumber1, phoneNumber2, rating,
				eMail, fax);
		return hotel;
	}
}
