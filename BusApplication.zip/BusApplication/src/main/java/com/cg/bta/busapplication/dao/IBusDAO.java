package com.cg.bta.busapplication.dao;

import com.cg.bta.busapplication.model.BusDetails;

public interface IBusDAO {

	public void addBusDetails(BusDetails busDetails);

}
