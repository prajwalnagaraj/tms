package com.cg.bta.busapplication.service;

import com.cg.bta.busapplication.model.BusDetails;

public interface IBusService {

	void addBusDetails(BusDetails busDetails);

}
