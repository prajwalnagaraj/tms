package com.cg.bta.busapplication.exceptions;

public class IDExistsException extends Exception {

	public IDExistsException() {
		super();
	}

	public IDExistsException(String message) {
		super(message);
	}
}
